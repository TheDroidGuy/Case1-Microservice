package com.gadgetMS.proj.restAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GadgetManagementSystemRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
