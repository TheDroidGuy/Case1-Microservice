package com.gadgetMS.proj.restAPI.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.gadgetMS.proj.restAPI.model.Gadget;


@DataJpaTest
//This annotation is added to give order of execution in proper order
@TestMethodOrder(OrderAnnotation.class)
class GadgetRepositoryTest {

	@Autowired
//	private GadgetRepository gadgetRepo;
	private GadgetRepository gadgetRepo;
	
	
//	JUnit Test for create gadget
	@Test
	@Order(1)
	public void saveGadgetTest() {
		Gadget gadget = new Gadget("Nothing Phone (1)", "Nothing", 5, 10000);
		
		gadgetRepo.save(gadget);
		
		assertThat(gadget.getId()).isGreaterThan(0);
	}
	
	
	
//	JUnit Test for Read gadget
	@Test
	@Order(2)
	public void getGadgetTest() {
		Gadget gadget = gadgetRepo.findById(1).get();
		
		assertThat(gadget.getId()).isEqualTo(1);
	}
	
	
	
//	JUnit Test for Read all gadget
	@Test
	@Order(3)
	public void getListOfGadgetTest() {
		List<Gadget> gadgets = gadgetRepo.findAll();
		
		assertThat(gadgets.size()).isGreaterThan(0);
	}
	
	
	
//	JUnit Test for update gadget
//	We could've also added assertThat statement and update other fields but for simplicity I've just done for 1 field
	@Test
	@Order(4)
	public void updateGadgetTest() {
		Gadget gadget = gadgetRepo.findById(1).get();
		
		gadget.setModelName("Nothing Phone (2)");
		
		Gadget updatedGadget = gadgetRepo.save(gadget);
		
		assertThat(updatedGadget.getModelName()).isEqualTo("Nothing Phone (2)");
	}
	
	
	
//	JUnit Test for delete gadget
	@Test
	@Order(5)
	public void deleteGadgetTest() {
		Gadget gadget = gadgetRepo.findById(1).get();
		
		gadgetRepo.delete(gadget);
		
		
//		Since the gadget has been deleted we need a null gadget01 to hold the value if we've the optionalGadget present
		Gadget gadget01 = null;
		Optional<Gadget> optionalGadget = gadgetRepo.findByModelName("Nothing Phone (2)");
		
		if(optionalGadget.isPresent()) {
			gadget01 = optionalGadget.get();
		}
		
		assertThat(gadget01).isNull();
	}
	
	
	
	
	
	
}
