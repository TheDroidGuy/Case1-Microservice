package com.gadgetMS.proj.restAPI.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gadgetMS.proj.restAPI.model.Gadget;
import com.gadgetMS.proj.restAPI.service.GadgetService;

//We can use @Controller annotation also but if we use it then we need to use @ResponseBody annotaion on every rest api we define inside this controller
@RestController
@RequestMapping("/api/gadgets") // We've added this @RequestMapping instead of adding Mapping to every API I create with in the controller
public class GadgetController {
	
	@Autowired
	private GadgetService gadgetService;
	
//	Build create gadget REST API
	@PostMapping
	public ResponseEntity<Gadget> saveGadget(@RequestBody Gadget gadget){
		return new ResponseEntity<Gadget>(gadgetService.saveGadget(gadget), HttpStatus.CREATED);
	}
	
	
//	Build get all gadget REST API
	@GetMapping
	public List<Gadget> getAllGadget(){
		return gadgetService.getAllGadgets();
	}
	
//	Build get gadget by id REST API
//	The client uses url like -> http:localhost:8080/api/gadget/1
	@GetMapping("{id}") //whtaever inside {} is path variable i.e., URL template variable
	public ResponseEntity<Gadget> getGadgetById(@PathVariable("id") int gadgetID){
		return new ResponseEntity<Gadget>(gadgetService.getGadgetById(gadgetID), HttpStatus.OK);
	}
	
	
//	Build update gadget REST API
//	The client uses url like -> http:localhost:8080/api/gadget/1
//	We've added ResponseEntity as return type as we want to create entire response of REST API like status, header, body etc
	@PutMapping("{id}")
	public ResponseEntity<Gadget> updateGadget(@PathVariable("id") int id, @RequestBody Gadget gadget){
		return new ResponseEntity<Gadget>(gadgetService.updateGadget(gadget, id), HttpStatus.OK);
	}
	
	
	
//	Build delete gadget REST API
//	The client uses url like -> http:localhost:8080/api/gadget/1
	@DeleteMapping("{id}")
	public ResponseEntity<String> deleteGadget(@PathVariable("id") int id){
		gadgetService.deleteGadget(id);
		return new ResponseEntity<String>("Gadget deleted successfully", HttpStatus.OK);
	}
	
	
	
}
