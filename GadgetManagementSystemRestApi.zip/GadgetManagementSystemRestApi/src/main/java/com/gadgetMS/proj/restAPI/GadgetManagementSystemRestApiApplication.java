package com.gadgetMS.proj.restAPI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.gadgetMS.proj.restAPI.model.Gadget;
import com.gadgetMS.proj.restAPI.repository.GadgetRepository;

//This class implements CommandLineRunner to load the below mentioned items when the application starts
@SpringBootApplication
public class GadgetManagementSystemRestApiApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(GadgetManagementSystemRestApiApplication.class, args);
	}

	
	@Autowired
	GadgetRepository gadgetRepo;
	
	@Override
	public void run(String... args) throws Exception {
		Gadget gadget1 = new Gadget("iPhone 13", "Apple", 2, 65000);
		gadgetRepo.save(gadget1);
		
		Gadget gadget2 = new Gadget("iPhone 13 Pro", "Apple", 1, 120000);
		gadgetRepo.save(gadget2);
		
		Gadget gadget3 = new Gadget("iPad Pro", "Apple", 3, 70000);
		gadgetRepo.save(gadget3);
		
		System.out.println("3 Values are pre-populated for testing purpose");
		
		
	}

}
