package com.gadgetMS.proj.restAPI.service;

import java.util.List;

import com.gadgetMS.proj.restAPI.model.Gadget;

public interface GadgetService {
	Gadget saveGadget(Gadget gadget);
	List<Gadget> getAllGadgets();
	Gadget getGadgetById(int id);
	Gadget updateGadget(Gadget gadget, int id);
	void deleteGadget(int id);
}
