package com.gadgetMS.proj.restAPI.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gadgetMS.proj.restAPI.model.Gadget;

public interface GadgetRepository extends JpaRepository<Gadget, Integer> {
//	This below method is created to test JUnit test for delete
	Optional<Gadget> findByModelName(String modelName);
}
