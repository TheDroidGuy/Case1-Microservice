package com.gadgetMS.proj.restAPI.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gadgetMS.proj.restAPI.exception.ResourceNotFoundException;
import com.gadgetMS.proj.restAPI.model.Gadget;
import com.gadgetMS.proj.restAPI.repository.GadgetRepository;
import com.gadgetMS.proj.restAPI.service.GadgetService;

@Service
public class GadgetServiceImpl implements GadgetService{

	@Autowired
	private GadgetRepository gadgetRepository;
	
	@Override
	public Gadget saveGadget(Gadget gadget) {
		return gadgetRepository.save(gadget);
	}

	@Override
	public List<Gadget> getAllGadgets() {
		return gadgetRepository.findAll();
	}

	@Override
	public Gadget getGadgetById(int id) {
		Optional<Gadget> gadget = gadgetRepository.findById(id);
		
		if(gadget.isPresent()) {
			return gadget.get();
		}
		else {
			throw new ResourceNotFoundException("Employee", "Id", id);
		}
		
	}

	@Override
	public Gadget updateGadget(Gadget gadget, int id) {
//		It Checks whether there is gadget with given id
		Gadget existingGadget = gadgetRepository.findById(id).orElseThrow(
				() -> new ResourceNotFoundException("Employee", "Id", id) //It's a lambda function to throw new exception if ther is no error
				);
		existingGadget.setMakerName(gadget.getMakerName());
		existingGadget.setModelName(gadget.getModelName());
		existingGadget.setPrice(gadget.getPrice());
		existingGadget.setQuantity(gadget.getQuantity());
		
		gadgetRepository.save(existingGadget);
		
		return existingGadget;
	}

	@Override
	public void deleteGadget(int id) {
		
//		Checks whether gadget exists with given id in db or not
		gadgetRepository.findById(id).orElseThrow(
				() -> new ResourceNotFoundException("Employee", "Id", id) //It's a lambda function to throw new exception if ther is no error
				);
		
		
		gadgetRepository.deleteById(id);
	}

}
