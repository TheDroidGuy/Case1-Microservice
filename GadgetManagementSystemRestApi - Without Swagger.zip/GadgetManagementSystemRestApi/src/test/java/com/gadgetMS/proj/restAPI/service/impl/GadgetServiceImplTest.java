package com.gadgetMS.proj.restAPI.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.gadgetMS.proj.restAPI.model.Gadget;
import com.gadgetMS.proj.restAPI.repository.GadgetRepository;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value=GadgetServiceImpl.class)
@EnableAutoConfiguration
@ContextConfiguration(classes= {GadgetServiceImpl.class})
class GadgetServiceImplTest {

//	Dependency is @MockBean
	@MockBean
	private GadgetRepository gadgetRepo;
	
//	Actual class under test is always @Autowired
	@Autowired
	private GadgetServiceImpl gadgetServiceImpl;
	
	@Test
	void testSaveGadget() {
		Gadget gadgetTest = new Gadget();
		gadgetTest.setModelName("Oneplus 10 pro");
		gadgetTest.setMakerName("Oneplus");
		gadgetTest.setPrice(70000);
		gadgetTest.setQuantity(3);
		
		Mockito.when(gadgetRepo.save(gadgetTest)).thenReturn(gadgetTest);
		
		assertThat(gadgetServiceImpl.saveGadget(gadgetTest)).isEqualTo(gadgetTest);
	}
	
	
//	This type tests with multiple items loaded
	@Test
	void testGetAllGadget() {
		Gadget gadgetTest1 = new Gadget();
		gadgetTest1.setModelName("Oneplus 10 pro");
		gadgetTest1.setMakerName("Oneplus");
		gadgetTest1.setPrice(70000);
		gadgetTest1.setQuantity(3);
		
		Gadget gadgetTest2 = new Gadget();
		gadgetTest2.setModelName("Oneplus 10 pro");
		gadgetTest2.setMakerName("Oneplus");
		gadgetTest2.setPrice(70000);
		gadgetTest2.setQuantity(3);
		
		List<Gadget> gadgetList = new ArrayList<>();
		gadgetList.add(gadgetTest1);
		gadgetList.add(gadgetTest2);
		
		Mockito.when(gadgetRepo.findAll()).thenReturn(gadgetList);
		
		assertThat(gadgetServiceImpl.getAllGadgets()).isEqualTo(gadgetList);
	}
	
	
//	This test method tests with only one item loaded
	@Test
	void testGetGadgetById() {
//		We're loading it directly so as we can't use setters on Optional type
		Optional<Gadget> gadgetTest = Optional.of(new Gadget("Oneplus 10 pro","Oneplus",2,10000));
		
		
		Mockito.when(gadgetRepo.findById(Mockito.anyInt())).thenReturn(gadgetTest);
		assertThat(Optional.of(gadgetServiceImpl.getGadgetById(Mockito.anyInt()))).isEqualTo(gadgetTest);
		
	}
	
	

}
